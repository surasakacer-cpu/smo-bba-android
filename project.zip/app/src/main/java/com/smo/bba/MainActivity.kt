package com.smo.bba

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val url = "https://script.google.com/macros/s/AKfycbzYd9-HsyahN8FXHfaM5szOP6lhuFE2P25WZWEZhTrhop_pcwbJWfspq6wk-oYGaKKj/exec"
    override fun onCreate(state: Bundle?) { super.onCreate(state); web = WebView(this); web.layoutParams = ViewGroup.LayoutParams(-1,-1); setContentView(web)
        web.settings.javaScriptEnabled = true; web.settings.domStorageEnabled = true; web.settings.allowFileAccess = true; web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient(); web.webChromeClient = object : WebChromeClient() { override fun onShowFileChooser(v: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean { chooser?.onReceiveValue(null); chooser=c; startActivityForResult(p.createIntent(), 42); return true } }
        web.loadUrl(url)
    }
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onActivityResult(r:Int, c:Int, d:Intent?) { super.onActivityResult(r,c,d); if(r==42){ chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d)); chooser=null } }
}
